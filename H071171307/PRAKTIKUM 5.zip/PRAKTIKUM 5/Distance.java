public interface Distance {

    public abstract double metreToKilo(double value);
    public abstract double metreToMilli(double value);
    public abstract double inchToMetre(double value);

}