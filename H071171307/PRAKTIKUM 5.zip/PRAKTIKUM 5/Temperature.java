public interface Temperature {

    public abstract double celciusToFahrnheit(double value);
    public abstract double celciusToKelvin(double value);

}