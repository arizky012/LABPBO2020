public interface Data {

    public abstract long teraToGiga(long value);
    public abstract long teraToMega(long value);
    public abstract long teraToKilo(long value);

}