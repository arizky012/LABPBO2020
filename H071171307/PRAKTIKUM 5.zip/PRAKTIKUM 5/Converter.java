public abstract class Converter {

    public abstract void start();
    public abstract void stop();
    

}